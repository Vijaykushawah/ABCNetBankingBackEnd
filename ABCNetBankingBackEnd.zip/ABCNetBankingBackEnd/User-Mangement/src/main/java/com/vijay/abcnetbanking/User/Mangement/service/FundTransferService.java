package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.FundTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.IntraBankTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.InterBankTransferDTO;

public interface FundTransferService {
    FundTransferDTO intraBankTransfer(IntraBankTransferDTO intraBankTransferDTO);
    FundTransferDTO interBankTransfer(InterBankTransferDTO interBankTransferDTO);
}
