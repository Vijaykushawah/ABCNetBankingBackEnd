package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Account;
import com.vijay.abcnetbanking.User.Mangement.model.Transaction;
import com.vijay.abcnetbanking.User.Mangement.repository.AccountRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.TransactionRepository;
import com.vijay.abcnetbanking.User.Mangement.service.TransactionService;
import com.vijay.abcnetbanking.User.Mangement.util.CsvGeneratorUtil;
import com.vijay.abcnetbanking.User.Mangement.util.PdfGeneratorUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private PdfGeneratorUtil pdfGenerator;

    @Autowired
    private CsvGeneratorUtil csvGenerator;

    @Autowired
    private AccountRepository accountRepository;

   
    

    @Override
    public List<TransactionDTO> getTransactionHistory(Long accountId, Date startDate, Date endDate) {
         Account account = accountRepository.findByAccountNumber(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found with account number " + accountId));
        List<Transaction> transactions = transactionRepository.findByAccountAndDateBetween(account, startDate, endDate);

       // List<Transaction> transactions = transactionRepository.findByAccountIdAndDateBetween(accountId, startDate, endDate);
        return transactions.stream().map(transaction -> {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.setId(transaction.getId());
            transactionDTO.setAmount(transaction.getAmount());
            transactionDTO.setDate(transaction.getDate());
            transactionDTO.setDescription(transaction.getDescription());
            return transactionDTO;
        }).collect(Collectors.toList());
    }

    @Override
    public byte[] generatePdfStatement(Long accountId, Date startDate, Date endDate) {
        List<TransactionDTO> transactions = getTransactionHistory(accountId, startDate, endDate);
        return pdfGenerator.generate(transactions);
    }

    

    @Override
    public byte[] generateCsvStatement(Long accountId, Date startDate, Date endDate) {
        List<TransactionDTO> transactions = getTransactionHistory(accountId, startDate, endDate);
        return csvGenerator.generate(transactions);
    }

    
    
}
