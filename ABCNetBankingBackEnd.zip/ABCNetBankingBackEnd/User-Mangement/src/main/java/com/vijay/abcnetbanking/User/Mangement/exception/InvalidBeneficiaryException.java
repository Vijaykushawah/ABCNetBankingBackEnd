package com.vijay.abcnetbanking.User.Mangement.exception;


public class InvalidBeneficiaryException extends RuntimeException {

    public InvalidBeneficiaryException(String message) {
        super(message);
    }
}
