package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.NotificationDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.NotificationSettingsDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Notification;
import java.util.List;

public interface NotificationService {
    void sendNotification(NotificationDTO notificationDTO);
    NotificationSettingsDTO saveNotificationSettings(Long userId, NotificationSettingsDTO settingsDTO);
    List<Notification> getNotificationHistory(Long userId);
    NotificationSettingsDTO getNotificationSettings(Long userId);
   
}
