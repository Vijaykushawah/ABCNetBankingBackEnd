package com.vijay.abcnetbanking.User.Mangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.vijay.abcnetbanking")
@ComponentScan(basePackages = "com.vijay.abcnetbanking")
@EntityScan(basePackages = "com.vijay.abcnetbanking")

public class UserMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMangementApplication.class, args);
	}

}
