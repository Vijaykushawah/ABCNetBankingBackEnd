package com.vijay.abcnetbanking.User.Mangement.dto;



import java.util.List;

import lombok.Data;

@Data
public class AccountDetailsDTO {

    private String accountNumber;
    private Double balance;
    private Double availableCredit;
    private String bankName; // New field for bank name
    private List<TransactionDTO> transactions;

    // Getters and Setters
}
