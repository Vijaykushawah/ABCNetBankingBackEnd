package com.vijay.abcnetbanking.User.Mangement.util;



import org.springframework.stereotype.Component;

@Component
public class SmsUtil {

    public void sendSms(String phoneNumber, String message) {
        // Placeholder for actual SMS sending logic
        // This could be an integration with an SMS gateway API
        System.out.println("Sending SMS to " + phoneNumber + ": " + message);
    }
}
