package com.vijay.abcnetbanking.User.Mangement.util;

import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.UserDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.stream.Stream;

@Component
public class PdfGeneratorUtil {

    public byte[] generate(List<TransactionDTO> transactions) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            PdfPTable table = new PdfPTable(4);
            table.addCell("ID");
            table.addCell("Amount");
            table.addCell("Date");
            table.addCell("Description");

            for (TransactionDTO transaction : transactions) {
                table.addCell(transaction.getId().toString());
                table.addCell(transaction.getAmount().toString());
                table.addCell(transaction.getDate().toString());
                table.addCell(transaction.getDescription());
            }

            document.add(table);
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return out.toByteArray();
    }

    public void generateTransactionHistoryPdf(OutputStream out, List<TransactionDTO> transactions, UserDTO user) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Add user information
            addUserInfo(document, user);

            // Add spacing
            document.add(Chunk.NEWLINE);

            // Create table with 4 columns
            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);

            // Set column widths
            float[] columnWidths = {1f, 2f, 2f, 3f};
            table.setWidths(columnWidths);

            // Add table header
            addTableHeader(table);

            // Add table rows
            addRows(table, transactions);

            // Add table to document
            document.add(table);
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    private void addUserInfo(Document document, UserDTO user) throws DocumentException {
        Paragraph userInfo = new Paragraph();
        userInfo.add(new Chunk("User Information\n", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16)));
     //   userInfo.add(new Chunk("Name: " + user.getName() + "\n", FontFactory.getFont(FontFactory.HELVETICA, 12)));
        userInfo.add(new Chunk("Email: " + user.getEmail() + "\n", FontFactory.getFont(FontFactory.HELVETICA, 12)));
      //  userInfo.add(new Chunk("Account Number: " + user.getAccountNumber() + "\n", FontFactory.getFont(FontFactory.HELVETICA, 12)));
        document.add(userInfo);
    }

    private void addTableHeader(PdfPTable table) {
        Stream.of("ID", "Amount", "Date", "Description")
                .forEach(columnTitle -> {
                    PdfPCell header = new PdfPCell();
                    header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    header.setBorderWidth(2);
                    header.setPhrase(new Phrase(columnTitle, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12)));
                    table.addCell(header);
                });
    }

    private void addRows(PdfPTable table, List<TransactionDTO> transactions) {
        for (TransactionDTO transaction : transactions) {
            table.addCell(new PdfPCell(new Phrase(transaction.getId().toString(), FontFactory.getFont(FontFactory.HELVETICA, 12))));
            table.addCell(new PdfPCell(new Phrase(transaction.getAmount().toString(), FontFactory.getFont(FontFactory.HELVETICA, 12))));
            table.addCell(new PdfPCell(new Phrase(transaction.getDate().toString(), FontFactory.getFont(FontFactory.HELVETICA, 12))));
            table.addCell(new PdfPCell(new Phrase(transaction.getDescription(), FontFactory.getFont(FontFactory.HELVETICA, 12))));
        }
    }
}
