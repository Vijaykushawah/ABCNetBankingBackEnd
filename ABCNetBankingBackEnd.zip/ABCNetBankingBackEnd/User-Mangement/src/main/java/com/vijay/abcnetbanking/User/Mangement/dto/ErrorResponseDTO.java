package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;


@Data
public class ErrorResponseDTO {
    
        
        private String message;
        private String status;

        public ErrorResponseDTO(String message, String status) {
            this.message = message;
            this.status = status;
        }

        

}
