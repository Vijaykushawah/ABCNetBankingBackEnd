package com.vijay.abcnetbanking.User.Mangement.util;

import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.List;

@Component
public class CsvGeneratorUtil {

    public byte[] generate(List<TransactionDTO> transactions) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(out);

        writer.println("ID,Amount,Date,Description");

        for (TransactionDTO transaction : transactions) {
            writer.printf("%d,%.2f,%s,%s%n",
                    transaction.getId(),
                    transaction.getAmount(),
                    transaction.getDate().toString(),
                    transaction.getDescription());
        }

        writer.flush();
        writer.close();

        return out.toByteArray();
    }
}
