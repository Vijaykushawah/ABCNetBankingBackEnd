package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class BeneficiaryDTO {

    private Long id;
    private Long accountNumber;
    private String name;
    private String email;
    private String address;
    private String mobile;


    
}
