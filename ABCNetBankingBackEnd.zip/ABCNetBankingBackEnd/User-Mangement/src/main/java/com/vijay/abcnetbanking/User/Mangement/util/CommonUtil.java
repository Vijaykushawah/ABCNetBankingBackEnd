package com.vijay.abcnetbanking.User.Mangement.util;



import java.util.Date;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class CommonUtil {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static boolean isValidPassword(String password) {
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).{8,}$";
        return password != null && password.matches(passwordPattern);
    }

    

     public static boolean isDateRangeInvalid(Date startDate, Date endDate) {
        Date now = new Date();
        long twelveMonthsInMillis = 12L * 30 * 24 * 60 * 60 * 1000;
        return startDate.before(new Date(now.getTime() - twelveMonthsInMillis)) || endDate.before(startDate);
    }

    // write generic method to convert entity to DTO
    //add try catch block to handle exception and check for null values and configure for missing properties and register JavaTimeModule
    public static <T> T convertToDTO(Object object, Class<T> clazz) {
        if (object == null) {
            return null;
        }
        try {
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return objectMapper.readValue(objectMapper.writeValueAsString(object), clazz);
        } catch (Exception e) {
            //return meaningful message
            throw new RuntimeException("Error converting object to DTO");
        }
    }

}
