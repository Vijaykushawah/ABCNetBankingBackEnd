package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class IntraBankTransferDTO {

    private Long fromAccountNumber;
    private Long toAccountNumber;
    private String bankName; // New field for bank name
    private Double amount;

    // Getters and Setters
}
