package com.vijay.abcnetbanking.User.Mangement.repository;



import com.vijay.abcnetbanking.User.Mangement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByMobile(String mobile);
    boolean existsByEmail(String email);
    boolean existsByMobile(String mobile);
    @Query(value = "SELECT * FROM users WHERE email = :emailOrMobile OR mobile = :emailOrMobile", nativeQuery = true)
    Optional<User> findByEmailOrMobile(@Param("emailOrMobile") String emailOrMobile);

    
}

