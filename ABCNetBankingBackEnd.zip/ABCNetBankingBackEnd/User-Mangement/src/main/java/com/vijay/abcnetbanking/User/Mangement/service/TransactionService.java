package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;

import java.util.Date;
import java.util.List;

public interface TransactionService {
    List<TransactionDTO> getTransactionHistory(Long accountId, Date startDate, Date endDate);
    byte[] generatePdfStatement(Long accountId, Date startDate, Date endDate);
    byte[] generateCsvStatement(Long accountId, Date startDate, Date endDate);
    
}
