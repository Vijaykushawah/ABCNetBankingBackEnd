package com.vijay.abcnetbanking.User.Mangement.model;


import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

// accountNumber must be unique and 10 digits add error message
    @Column(nullable = false, unique = true)
    private Long accountNumber;

    private Double balance;
    private Double availableCredit;

    @ManyToOne
    @JoinColumn(name = "email", referencedColumnName = "email")
    private User user;

    @ManyToOne
    @JoinColumn(name = "bankId", referencedColumnName = "id")
    private Bank bank;

    
    @Lob
    private byte[] highSchoolCertificate;
    
    @Lob
    private byte[] signature;

    @Lob
    private byte[] photo;

    @OneToMany(mappedBy = "account")
    private List<Transaction> transactions;


}
