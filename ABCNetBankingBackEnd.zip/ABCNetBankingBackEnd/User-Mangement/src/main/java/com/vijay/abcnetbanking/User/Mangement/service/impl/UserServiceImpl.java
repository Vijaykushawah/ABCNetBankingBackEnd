package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.UserDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.DuplicateUserException;
import com.vijay.abcnetbanking.User.Mangement.exception.InvalidUserException;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.model.UserToken;
import com.vijay.abcnetbanking.User.Mangement.repository.UserRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.UserTokenRepository;
import com.vijay.abcnetbanking.User.Mangement.security.JwtTokenProvider;
import com.vijay.abcnetbanking.User.Mangement.service.UserService;
import com.vijay.abcnetbanking.User.Mangement.util.EncryptionUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.util.Optional;
import java.util.Random;
import java.time.LocalDateTime;
import java.util.Collections;
import static com.vijay.abcnetbanking.User.Mangement.util.CommonUtil.convertToDTO;


@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

     @Autowired
    private UserTokenRepository userTokenRepository;

    @Override
    public User createUser(@Valid User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new DuplicateUserException("Email or mobile number already registered.");
        }
        if (userRepository.existsByMobile(user.getMobile())) {
            throw new DuplicateUserException("Email or mobile number already registered.");
        }
        user.set2FAEnabled(false);
        user.setPassword(EncryptionUtil.encrypt(user.getPassword()));
        user.setRoles(Collections.singleton("USER")); // Assign default role
        user.setActive(true);
        User savedUser = userRepository.save(user);
        return convertToDTO(savedUser, UserDTO.class);
    }

    @Override
    public String generate2FACode(User user) {
        String code = String.format("%06d", new Random().nextInt(999999));
        user.setTwoFACode(code);
        userRepository.save(user);
        return code;
    }

    @Override
    public boolean verify2FACode(User user, String code) {
        return user.getTwoFACode().equals(code);
    }

    @Override
    public User save(User user) {
        user.setPassword(EncryptionUtil.encrypt(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public User update(User user) {
        return userRepository.save(user);
    }

    @Override
    public User findById(Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElse(null);
    }

    @Override

    public User findByEmail(String email) {

        return userRepository.findByEmail(email).orElse(null);

    }

    @Override
    public User findByMobile(String mobile) {
        return userRepository.findByMobile(mobile).orElse(null);
    }

    @Override
    public User findByMobileOrEmail(String mobileOrEmail) {
         Optional<User> userOptional = userRepository.findByEmailOrMobile(mobileOrEmail);
         return userOptional.orElse(null);

    }

    @Override
    public String generateOtp(User user) {
        String otp = String.format("%06d", new Random().nextInt(999999));
        user.setOtp(otp);
        user.setOtpGeneratedTime(LocalDateTime.now());
        userRepository.save(user);
        return otp;
    }

        @Override
    public boolean verifyOtp(User user, String otp) {
        if (otp.equals(user.getOtp())) {
            LocalDateTime otpGeneratedTime = user.getOtpGeneratedTime();
            if (otpGeneratedTime != null && otpGeneratedTime.plusMinutes(2).isAfter(LocalDateTime.now())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public UserDTO loginUser(User loginRequest) {
        User user = userRepository.findByEmail(loginRequest.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));
                if (!user.isActive()) {
                    throw new InvalidUserException("Account is suspended. Please contact support.");
                }

        // Decrypt the stored password
        String decryptedPassword = EncryptionUtil.decrypt(user.getPassword());

        // Authenticate the user
        if (!decryptedPassword.equals(loginRequest.getPassword())) {
            throw new InvalidUserException("Invalid email or password");
        }

        Authentication authentication = new UsernamePasswordAuthenticationToken(
                loginRequest.getEmail(), loginRequest.getPassword()
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Generate JWT token
        String token = jwtTokenProvider.generateToken(authentication);

        // Save the token to the database
        UserToken userToken = new UserToken();
        userToken.setUserId(user.getId());
        userToken.setToken(token);
        userTokenRepository.save(userToken);

        UserDTO userDTO = convertToDTO(user, UserDTO.class);
        userDTO.setToken(token);
        return userDTO;
    }

    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
    }

}