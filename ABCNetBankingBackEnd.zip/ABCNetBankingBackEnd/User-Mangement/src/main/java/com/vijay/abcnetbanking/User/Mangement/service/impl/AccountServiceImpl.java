package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.AccountOpeningDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.BankDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.DepositDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.UserDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Account;
import com.vijay.abcnetbanking.User.Mangement.model.Bank;
import com.vijay.abcnetbanking.User.Mangement.model.Transaction;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.repository.AccountRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.BankRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.TransactionRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.UserRepository;
import com.vijay.abcnetbanking.User.Mangement.service.AccountService;
import com.vijay.abcnetbanking.User.Mangement.util.CommonUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService {

    @Override
    public List<TransactionDTO> getTransactionsByAccountNumber(Long accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found with account number " + accountNumber));

        return account.getTransactions().stream()
            .map(transaction -> {
                TransactionDTO transactionDTO = new TransactionDTO();
                transactionDTO.setId(transaction.getId());
                transactionDTO.setAmount(transaction.getAmount());
                transactionDTO.setDate(transaction.getDate());
                transactionDTO.setDescription(transaction.getDescription());
                transactionDTO.setStatus(transaction.getStatus());
                transactionDTO.setType(transaction.getType());
                return transactionDTO;
            })
            .collect(Collectors.collectingAndThen(Collectors.toList(), list -> {
                java.util.Collections.reverse(list);
                return list;
            }));
    }

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BankRepository bankRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public AccountOpeningDTO getAccountDetails(Long accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber).orElseThrow(() -> new RuntimeException("Account not found"));
        AccountOpeningDTO accountOpeningDTO1 = convertAccountToAccountOpeningDTO(account); 
        return accountOpeningDTO1;
        }

        @Override
        public List<AccountOpeningDTO> getAccountDetailsByEmail(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found with email " + email));

        List<Account> accounts = accountRepository.findByUser(user);
        if (accounts.isEmpty()) {
            throw new RuntimeException("No accounts found for user with email " + email);
        }

        return accounts.stream()
            .map(this::convertAccountToAccountOpeningDTO)
            .collect(Collectors.toList());
        }

        @Override
        public AccountOpeningDTO openAccount(AccountOpeningDTO accountOpeningDTO) {
       Account account = new Account();
        account.setAccountNumber(accountOpeningDTO.getAccountNumber());
        account.setBalance(0.0);
        account.setAvailableCredit(0.0);

        Optional<User> user = userRepository.findByEmail(accountOpeningDTO.getEmail());
        if (user.isPresent()) {
            account.setUser(user.get());
        } else {
            throw new RuntimeException("User not found with email " + accountOpeningDTO.getEmail());
        }

        Optional<Bank> bank = bankRepository.findById(accountOpeningDTO.getBankId());
        if (bank.isPresent()) {
            account.setBank(bank.get());
        } else {
            throw new RuntimeException("Bank not found with id " + accountOpeningDTO.getBankId());
        }

        try {
            account.setHighSchoolCertificate(accountOpeningDTO.getHighSchoolCertificate().getBytes());
            account.setSignature(accountOpeningDTO.getSignature().getBytes());
            account.setPhoto(accountOpeningDTO.getPhoto().getBytes());
        } catch (IOException e) {
            throw new RuntimeException("Failed to process files", e);
        }

        Account savedAccount = accountRepository.save(account);
        AccountOpeningDTO accountOpeningDTO1 = convertAccountToAccountOpeningDTO(savedAccount);
        return accountOpeningDTO1;
    }

    @Override
    public void depositMoney(DepositDTO depositDTO) {
        Account account = accountRepository.findByAccountNumber(depositDTO.getAccountNumber())
                .orElseThrow(() -> new RuntimeException("Account not found with account number " + depositDTO.getAccountNumber()));

        account.setBalance(account.getBalance() + depositDTO.getAmount());
        accountRepository.save(account);

        Transaction transaction = new Transaction();
        transaction.setAccount(account);
        transaction.setAmount(depositDTO.getAmount());
        transaction.setCreatedDate(java.sql.Timestamp.valueOf(LocalDateTime.now()));
        transaction.setType("CREDIT");
        transaction.setStatus("SUCCESS");
        transaction.setDate(java.sql.Timestamp.valueOf(LocalDateTime.now()));
        transaction.setDescription("Deposit");

        transactionRepository.save(transaction);
    }

    //write private method to convert Account to AccountOpeningDTO
    private AccountOpeningDTO convertAccountToAccountOpeningDTO(Account account) {
        //use CommonUtil.convertToDTO method to convert the model to dto

        AccountOpeningDTO accountOpeningDTO1 = new AccountOpeningDTO();
        UserDTO userDTO = new UserDTO();
        BankDTO bankDTO = new BankDTO();
        userDTO = CommonUtil.convertToDTO(account.getUser(), UserDTO.class);
        bankDTO = CommonUtil.convertToDTO(account.getBank(), BankDTO.class);

        accountOpeningDTO1.setUser(userDTO);
        accountOpeningDTO1.setBank(bankDTO);
        accountOpeningDTO1.setAccountNumber(account.getAccountNumber());
        // fix Cannot invoke "java.util.List.stream()" because the return value of "com.vijay.abcnetbanking.User.Mangement.model.Account.getTransactions()" is null
        if (account.getTransactions() == null) {
            account.setTransactions(null);    
        }else{
            accountOpeningDTO1.setTransactions(account.getTransactions().stream().map(transaction -> {
                TransactionDTO transactionDTO = new TransactionDTO();
                transactionDTO.setId(transaction.getId());
                transactionDTO.setAmount(transaction.getAmount());
                transactionDTO.setDate(transaction.getDate());
                transactionDTO.setDescription(transaction.getDescription());
                transactionDTO.setStatus(transaction.getStatus());
                transactionDTO.setType(transaction.getType());

                return transactionDTO;
            }).collect(Collectors.toList()));
        }
        accountOpeningDTO1.setBalance(account.getBalance());
        accountOpeningDTO1.setAvailableCredit(account.getAvailableCredit());

        return accountOpeningDTO1;
    }
}
