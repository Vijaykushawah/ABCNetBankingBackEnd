package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.NotificationDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.NotificationSettingsDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Notification;
import com.vijay.abcnetbanking.User.Mangement.model.NotificationSettings;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.repository.NotificationRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.NotificationSettingsRepository;
import com.vijay.abcnetbanking.User.Mangement.service.NotificationService;
import com.vijay.abcnetbanking.User.Mangement.util.CommonUtil;
import com.vijay.abcnetbanking.User.Mangement.util.EmailUtil;
import com.vijay.abcnetbanking.User.Mangement.util.SmsUtil;

import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vijay.abcnetbanking.User.Mangement.service.UserService;

@Service
public class NotificationServiceImpl implements NotificationService {

    
    @Autowired
    private UserService userService;

    @Autowired
    private EmailUtil emailUtil;

    @Autowired
    private SmsUtil smsUtil;

     @Autowired
    private NotificationRepository notificationRepository;


     @Autowired
    private NotificationSettingsRepository notificationSettingsRepository;

    

    @Override
    public NotificationSettingsDTO saveNotificationSettings(Long userId, NotificationSettingsDTO settingsDTO) {
        // Implementation for saving notification settings
        //  get user by userId from userService
        User  user = userService.findById(userId);
        if(user == null){
            throw new RuntimeException("User not found with id " + userId);
        }

        NotificationSettings notificationSettings = notificationSettingsRepository.findByUserId(userId);
        if (notificationSettings == null) {
            notificationSettings = new NotificationSettings();
            notificationSettings.setUser(user);
            notificationSettings.setCreatedDate(new Date());
        }
        BeanUtils.copyProperties(settingsDTO, notificationSettings);
        NotificationSettings savedSettings = notificationSettingsRepository.save(notificationSettings);

        NotificationSettingsDTO savedSettingsDTO =CommonUtil.convertToDTO(savedSettings, NotificationSettingsDTO.class);
        return savedSettingsDTO;
    }

    @Override
    public NotificationSettingsDTO getNotificationSettings(Long userId) {
        NotificationSettings settings = notificationSettingsRepository.findByUserId(userId);
        if (settings == null) {
            return null;
        }
        return CommonUtil.convertToDTO(settings, NotificationSettingsDTO.class);
    }

    @Override
    public List<Notification> getNotificationHistory(Long userId) {
        return notificationRepository.findByUserId(userId);
    }

    @Override
    public void sendNotification(NotificationDTO notificationDTO) {
        //get user by email from userService
        User user = userService.findByEmail(notificationDTO.getEmail());
        if (user != null) {
              }else{
            user = userService.findByMobile(notificationDTO.getPhoneNumber());
            if(user == null)
            {
            throw new RuntimeException("User not found with email or mobile number " + notificationDTO.getPhoneNumber());
        }
        }
        // read notification settings from database
        NotificationSettings settings = notificationSettingsRepository.findByUserId(user.getId());
        if (settings == null) {
            throw new RuntimeException("Notification settings not found for user with id "+ user.getId()); 
        }
        // check if emailAlerts or smsAlerts is trur in settings then send email or sms
        if (settings.getEmailAlerts() != null && settings.getEmailAlerts() && notificationDTO.getEmail() != null) {
            emailUtil.sendEmail(notificationDTO.getEmail(), notificationDTO.getSubject(), notificationDTO.getMessage());
        }
        if (settings.getSmsAlerts() != null && settings.getSmsAlerts() && notificationDTO.getPhoneNumber() != null) {
            smsUtil.sendSms(notificationDTO.getPhoneNumber(), notificationDTO.getMessage());
        }

        

        Notification notification = new Notification();
        BeanUtils.copyProperties(notificationDTO, notification);
        notification.setUser(user);
        notification.setDate(new Date());
        notificationRepository.save(notification);
    }
}
