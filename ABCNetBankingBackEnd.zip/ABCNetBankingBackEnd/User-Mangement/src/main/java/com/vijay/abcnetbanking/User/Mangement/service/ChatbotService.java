package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.ChatRequestDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.ChatResponseDTO;

public interface ChatbotService {
    ChatResponseDTO handleChatRequest(ChatRequestDTO chatRequestDTO);
}
