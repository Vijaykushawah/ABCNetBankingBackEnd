package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.UserDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.DuplicateUserException;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.service.UserService;
import com.vijay.abcnetbanking.User.Mangement.util.CommonUtil;
import com.vijay.abcnetbanking.User.Mangement.util.EncryptionUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.validation.FieldError;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> createUser(@Valid @RequestBody User user) {
        try {
            User createdUser = userService.createUser(user);
            return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
        } catch (DuplicateUserException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        } catch (Exception e) {
            return new ResponseEntity<>("Invalid request format.", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/2fa")
    public ResponseEntity<?> generate2FACode(@RequestParam String mobile) {
        User user = userService.findByMobile(mobile);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        String code = userService.generate2FACode(user);
        // Send the code to the user via SMS
        System.out.println("2FA code: " + code);
        
        return new ResponseEntity<>("2FA code sent.", HttpStatus.OK);
    }

    @PostMapping("/2fa/verify")
    public ResponseEntity<?> verify2FACode(@RequestParam String mobile, @RequestParam String code) {
        User user = userService.findByMobile(mobile);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        if (userService.verify2FACode(user, code)) {
            user.set2FAEnabled(true);
            userService.save(user);
            return new ResponseEntity<>("2FA verified.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid 2FA code.", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestParam String mobileOrEmail) {
        User user = userService.findByMobileOrEmail(mobileOrEmail);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        String otp = userService.generateOtp(user);
        // Send the OTP to the user's mobile number or email
        System.out.println("OTP: " + otp);
        return new ResponseEntity<>("OTP sent.", HttpStatus.OK);
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestParam String mobileOrEmail, @RequestParam String otp, @RequestParam String newPassword) {
        User user = userService.findByMobileOrEmail(mobileOrEmail);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        if (!CommonUtil.isValidPassword(newPassword)) {
            return new ResponseEntity<>("Password must be at least 8 characters long and include uppercase, lowercase, and a special character.", HttpStatus.BAD_REQUEST);
        }
        if (userService.verifyOtp(user, otp)) {
            user.setPassword(EncryptionUtil.encrypt(newPassword));
            userService.update(user);
            return new ResponseEntity<>("Password reset successfully.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid OTP.", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/otp/verify")
    public ResponseEntity<?> otpVerify(@RequestParam String mobileOrEmail, @RequestParam String otp) {
        User user = userService.findByMobileOrEmail(mobileOrEmail);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        if (userService.verifyOtp(user, otp)) {
            return new ResponseEntity<>("OTP verified.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid OTP.", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User loginRequest) {
        try {
            UserDTO loggedInUser = userService.loginUser(loginRequest);
            return ResponseEntity.ok(loggedInUser);
        } catch (Exception e) {
            return ResponseEntity.status(401).body(e.getMessage());
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
        userService.logout(request, response);
        return ResponseEntity.noContent().build();
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
}