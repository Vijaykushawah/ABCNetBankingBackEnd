package com.vijay.abcnetbanking.User.Mangement.repository;

import com.vijay.abcnetbanking.User.Mangement.model.Account;
import com.vijay.abcnetbanking.User.Mangement.model.Transaction;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccountIdAndDateBetween(Long accountId, Date startDate, Date endDate);
// find by account 
    List<Transaction> findByAccount(Account account);

    List<Transaction> findByAccountAndDateBetween(Account account, Date startDate, Date endDate);
// find by account and date between startdate & enddate  and  enddate  equal to end date
   
}
