package com.vijay.abcnetbanking.User.Mangement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
@Data
public class BankDTO {

    @NotBlank(message = "Bank name is required")
    private String name;

    @NotBlank(message = "Bank branch is required")
    private String branch;

    @Pattern(regexp = "\\d{9}", message = "MICR code must be 9 digits")
    private String micrCode;

    @Pattern(regexp = "[A-Z]{4}0[A-Z0-9]{6}", message = "IFSC code must be 11 characters")
    private String ifscCode;

    @NotBlank(message = "Branch address is required")
    private String address;

    @NotBlank(message = "City is required")
    private String city;

    @NotBlank(message = "State is required")
    private String state;

    @NotBlank(message = "Country is required")
    private String country;

    @NotNull(message = "Bank status is required")
    private Boolean status;

    // Getters and Setters
}
