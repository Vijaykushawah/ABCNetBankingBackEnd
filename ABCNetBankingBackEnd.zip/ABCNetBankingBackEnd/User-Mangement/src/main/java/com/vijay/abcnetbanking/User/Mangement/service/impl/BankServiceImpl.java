package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.BankDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Bank;
import com.vijay.abcnetbanking.User.Mangement.repository.BankRepository;
import com.vijay.abcnetbanking.User.Mangement.service.BankService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BankServiceImpl implements BankService {

    @Autowired
    private BankRepository bankRepository;

    @Override
    public Bank createBank(BankDTO bankDTO) {
        Bank bank = new Bank();
        bank.setName(bankDTO.getName());
        bank.setBranch(bankDTO.getBranch());
        bank.setMicrCode(bankDTO.getMicrCode());
        bank.setIfscCode(bankDTO.getIfscCode());
        bank.setAddress(bankDTO.getAddress());
        bank.setCity(bankDTO.getCity());
        bank.setState(bankDTO.getState());
        bank.setCountry(bankDTO.getCountry());
        bank.setStatus(bankDTO.getStatus());
        return bankRepository.save(bank);
    }

    @Override
    public Bank updateBank(Long id, BankDTO bankDTO) {
        Optional<Bank> optionalBank = bankRepository.findById(id);
        if (optionalBank.isPresent()) {
            Bank bank = optionalBank.get();
            bank.setName(bankDTO.getName());
            bank.setBranch(bankDTO.getBranch());
            bank.setMicrCode(bankDTO.getMicrCode());
            bank.setIfscCode(bankDTO.getIfscCode());
            bank.setAddress(bankDTO.getAddress());
            bank.setCity(bankDTO.getCity());
            bank.setState(bankDTO.getState());
            bank.setCountry(bankDTO.getCountry());
            bank.setStatus(bankDTO.getStatus());
            return bankRepository.save(bank);
        } else {
            throw new RuntimeException("Bank not found with id " + id);
        }
    }

    @Override
    public void deleteBank(Long id) {
        bankRepository.deleteById(id);
    }

    @Override
    public Bank getBankById(Long id) {
        return bankRepository.findById(id).orElseThrow(() -> new RuntimeException("Bank not found with id " + id));
    }

    @Override
    public List<Bank> getAllBanks() {
        return bankRepository.findAll();
    }
}
