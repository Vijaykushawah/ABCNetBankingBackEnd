package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.ErrorResponseDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.FundTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.IntraBankTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.InsufficientBalanceException;
import com.vijay.abcnetbanking.User.Mangement.exception.InvalidBeneficiaryException;
import com.vijay.abcnetbanking.User.Mangement.dto.InterBankTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.service.FundTransferService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/fundtransfer")
public class FundTransferController {

    @Autowired
    private FundTransferService fundTransferService;

     @PostMapping("/intra")
    public ResponseEntity<?> intraBankTransfer(@RequestBody IntraBankTransferDTO intraBankTransferDTO) {
        try {
            FundTransferDTO fundTransferDTO = fundTransferService.intraBankTransfer(intraBankTransferDTO);
            return ResponseEntity.ok(fundTransferDTO);
        } catch (InsufficientBalanceException e) {
           return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }

    @PostMapping("/inter")
    public ResponseEntity<?> interBankTransfer(@RequestBody InterBankTransferDTO interBankTransferDTO) {
        try {
            FundTransferDTO fundTransferDTO = fundTransferService.interBankTransfer(interBankTransferDTO);
            return ResponseEntity.ok(fundTransferDTO);
        } catch (InvalidBeneficiaryException | InsufficientBalanceException e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }
}
