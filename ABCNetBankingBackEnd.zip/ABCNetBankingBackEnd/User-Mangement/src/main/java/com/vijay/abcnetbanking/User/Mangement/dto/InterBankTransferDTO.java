package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class InterBankTransferDTO {

    private Long fromAccountNumber;
    private Long toAccountNumber;
    private Double amount;
    private String bankName;
    private String transferType; // NEFT, RTGS, IMPS

    // Getters and Setters
}
