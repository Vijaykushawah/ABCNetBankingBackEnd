package com.vijay.abcnetbanking.User.Mangement.util;

import org.springframework.stereotype.Component;
import java.io.BufferedReader;
import java.io.InputStreamReader;

@Component
public class LangChainUtil {

    public String getResponse(String query) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("python", "generate_text.py", query);
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            process.waitFor();
            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Sorry, I couldn't understand your question.";
        }
    }
}