package com.vijay.abcnetbanking.User.Mangement.model;



import java.util.Random;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Entity
public class Bank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Bank name is required")
    private String name;

    @NotBlank(message = "Bank branch is required")
    private String branch;

    @Pattern(regexp = "\\d{9}", message = "MICR code must be 9 digits")
    private String micrCode;

    @Pattern(regexp = "[A-Z]{4}0[A-Z0-9]{6}", message = "IFSC code must be 11 characters")
    private String ifscCode;

    @NotBlank(message = "Branch address is required")
    private String address;

    @NotBlank(message = "City is required")
    private String city;

    @NotBlank(message = "State is required")
    private String state;

    @NotBlank(message = "Country is required")
    private String country;

  

    private Boolean status = true;
    
    @Pattern(regexp = "\\d{5}", message = "Branch code must be 5 digits")
    private String branchCode;

    @PrePersist
    @PreUpdate
    private void ensureBranchCode() {
        if (this.branchCode == null || this.branchCode.isEmpty()) {
            this.branchCode = generateBranchCode();
        }
    }

    private String generateBranchCode() {
        // Implement your logic to generate a unique 5-digit branch code
        // For example, you can use a random number generator or a sequence
        return String.format("%05d", new Random().nextInt(100000));
    }

    // Getters and Setters
}
