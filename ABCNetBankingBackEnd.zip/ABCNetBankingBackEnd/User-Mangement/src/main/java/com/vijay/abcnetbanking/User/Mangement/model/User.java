package com.vijay.abcnetbanking.User.Mangement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is mandatory")
    private String email;

    @Column(nullable = false, unique = true)
    @Pattern(regexp = "^\\d{10}$", message = "Mobile number must be 10 digits")
    @NotBlank(message = "Mobile number is mandatory")
    private String mobile;

    @Column(nullable = false)
    @Size(min = 8, message = "Password must be at least 8 characters long")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).+$", message = "Password must include uppercase, lowercase, and a special character")
    private String password;

    @ElementCollection(fetch = FetchType.EAGER)
    private Set<String> roles = new HashSet<>();

    @Column(nullable = false)
    private boolean is2FAEnabled = false;

    @Column
    private String twoFACode;

    @Column
    private String otp;

    @Column
    private LocalDateTime otpGeneratedTime;

    @Column
    private boolean active; // New field to indicate if the account is active

    



    
}