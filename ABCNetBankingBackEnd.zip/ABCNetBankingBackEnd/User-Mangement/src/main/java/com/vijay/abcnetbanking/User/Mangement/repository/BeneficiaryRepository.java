package com.vijay.abcnetbanking.User.Mangement.repository;

import com.vijay.abcnetbanking.User.Mangement.model.Beneficiary;
import com.vijay.abcnetbanking.User.Mangement.model.User;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long> {
    Optional<Beneficiary> findByAccountNumber(Long accountNumber);
    boolean existsByAccountNumber(Long accountNumber);
    boolean existsByAccountNumberAndUserId(Long accountNumber, Long userId);
    List<Beneficiary> findByUser(User user);
}
