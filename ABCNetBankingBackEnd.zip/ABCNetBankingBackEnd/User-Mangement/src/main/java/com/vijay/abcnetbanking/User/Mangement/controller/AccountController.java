package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.AccountOpeningDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.DepositDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.ErrorResponseDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import com.vijay.abcnetbanking.User.Mangement.service.AccountService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;



@RestController
@RequestMapping("/api/account")
public class AccountController {

    @Autowired
    private AccountService accountService;


    @PostMapping("/open")
    public ResponseEntity<AccountOpeningDTO> openAccount(
            @RequestParam("email") String email,
            @RequestParam("accountNumber") Long accountNumber,
            @RequestParam("bankId") Long bankId,
            @RequestParam("highSchoolCertificate") MultipartFile highSchoolCertificate,
            @RequestParam("signature") MultipartFile signature,
            @RequestParam("photo") MultipartFile photo) {

        AccountOpeningDTO accountOpeningDTO = new AccountOpeningDTO();
        accountOpeningDTO.setEmail(email);
        accountOpeningDTO.setAccountNumber(accountNumber);
        accountOpeningDTO.setBankId(bankId);
        accountOpeningDTO.setHighSchoolCertificate(highSchoolCertificate);
        accountOpeningDTO.setSignature(signature);
        accountOpeningDTO.setPhoto(photo);
        
        AccountOpeningDTO openedAccount = accountService.openAccount(accountOpeningDTO);
        return ResponseEntity.ok(openedAccount);
        
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<AccountOpeningDTO> getAccountDetails(@PathVariable Long  accountNumber) {
        AccountOpeningDTO accountOpeningDTO = accountService.getAccountDetails(accountNumber);
        return ResponseEntity.ok(accountOpeningDTO);
    }

     @GetMapping("/email/{email}")
    public ResponseEntity<?> getAccountDetailsByEmail(@PathVariable String email) {
        try {
            List<AccountOpeningDTO> accountOpeningDTO = accountService.getAccountDetailsByEmail(email);
            return ResponseEntity.ok(accountOpeningDTO);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }

    @PostMapping("/deposit")
    public ResponseEntity<?> depositMoney(@RequestBody DepositDTO depositDTO) {
        try {
            accountService.depositMoney(depositDTO);
            return ResponseEntity.ok().body("Deposit successful");
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }

    @GetMapping("/{accountNumber}/transactions")
    public ResponseEntity<?> getTransactionsByAccountNumber(@PathVariable Long accountNumber) {
        try {
            List<TransactionDTO> transactions = accountService.getTransactionsByAccountNumber(accountNumber);
            return ResponseEntity.ok(transactions);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }

}


