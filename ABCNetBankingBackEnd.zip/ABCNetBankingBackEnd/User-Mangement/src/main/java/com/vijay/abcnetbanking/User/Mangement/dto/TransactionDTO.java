package com.vijay.abcnetbanking.User.Mangement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class TransactionDTO {

    private Long id;
    private Double amount;
    private Date date;
    private String description;
    private String type;
    private String status;

    // Getters and Setters
}
