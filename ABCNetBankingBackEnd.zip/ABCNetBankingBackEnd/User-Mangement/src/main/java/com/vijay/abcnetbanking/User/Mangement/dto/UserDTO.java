package com.vijay.abcnetbanking.User.Mangement.dto;

import java.util.Set;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
public class UserDTO extends User {
    private Long id;
    private String email;
    private String mobile;
    private Set<String> roles;
    private boolean is2FAEnabled;
    private boolean active;
    private String token;

    @Override
    public String getPassword() {
        return null; // Hide password
    }

    // hide otp
    @Override
    public String getOtp() {
        return null;
    }

    // hide twoFACode
    @Override
    public String getTwoFACode() {
        return null;
    }

    // hide otpGeneratedTime
    @Override
    public LocalDateTime getOtpGeneratedTime() {
        return null;
    }

    @Override
    public void setPassword(String password) {
        // Do nothing to hide password
    }
}
