package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.BankDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Bank;
import com.vijay.abcnetbanking.User.Mangement.service.BankService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bank")
public class BankController {

    @Autowired
    private BankService bankService;

    @PostMapping
    public ResponseEntity<Bank> createBank(@Valid @RequestBody BankDTO bankDTO) {
        Bank bank = bankService.createBank(bankDTO);
        return ResponseEntity.ok(bank);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Bank> updateBank(@PathVariable Long id, @Valid @RequestBody BankDTO bankDTO) {
        Bank bank = bankService.updateBank(id, bankDTO);
        return ResponseEntity.ok(bank);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBank(@PathVariable Long id) {
        bankService.deleteBank(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Bank> getBankById(@PathVariable Long id) {
        Bank bank = bankService.getBankById(id);
        return ResponseEntity.ok(bank);
    }

    @GetMapping
    public ResponseEntity<List<Bank>> getAllBanks() {
        List<Bank> banks = bankService.getAllBanks();
        return ResponseEntity.ok(banks);
    }
}
