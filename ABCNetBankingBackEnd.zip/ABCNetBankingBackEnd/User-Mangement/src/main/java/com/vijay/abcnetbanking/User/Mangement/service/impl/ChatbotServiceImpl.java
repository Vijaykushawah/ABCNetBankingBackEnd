package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.ChatRequestDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.ChatResponseDTO;
import com.vijay.abcnetbanking.User.Mangement.model.ChatInteraction;
import com.vijay.abcnetbanking.User.Mangement.repository.ChatInteractionRepository;
import com.vijay.abcnetbanking.User.Mangement.service.ChatbotService;
import com.vijay.abcnetbanking.User.Mangement.util.LangChainUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ChatbotServiceImpl implements ChatbotService {

    @Autowired
    private LangChainUtil langChainUtil;

    @Autowired
    private ChatInteractionRepository chatInteractionRepository;

    @Override
    public ChatResponseDTO handleChatRequest(ChatRequestDTO chatRequestDTO) {
        String response = langChainUtil.getResponse(chatRequestDTO.getQuery());

        // Store interaction in the database
        ChatInteraction interaction = new ChatInteraction();
        interaction.setUserQuery(chatRequestDTO.getQuery());
        interaction.setBotResponse(response);
        interaction.setTimestamp(new Date());
        chatInteractionRepository.save(interaction);

        ChatResponseDTO chatResponseDTO = new ChatResponseDTO();
        chatResponseDTO.setResponse(response);
        return chatResponseDTO;
    }
}
