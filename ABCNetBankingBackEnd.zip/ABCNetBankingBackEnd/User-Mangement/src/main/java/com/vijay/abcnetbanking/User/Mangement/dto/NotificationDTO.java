package com.vijay.abcnetbanking.User.Mangement.dto;

import java.util.Date;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class NotificationDTO {

    @Email(message = "Invalid email format")
    private String email;

    @Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "Invalid phone number")
    private String phoneNumber;
    private String subject;
    private String message;
    private Date sentDate;
    private String type;
    private String status;


    // Getters and Setters
}
