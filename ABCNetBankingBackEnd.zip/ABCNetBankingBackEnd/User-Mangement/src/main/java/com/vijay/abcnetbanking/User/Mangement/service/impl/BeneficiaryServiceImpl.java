package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.BeneficiaryDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.BeneficiaryAlreadyExistsException;
import com.vijay.abcnetbanking.User.Mangement.exception.InvalidBeneficiaryException;

import com.vijay.abcnetbanking.User.Mangement.model.Beneficiary;
import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.repository.BeneficiaryRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.AccountRepository;
import com.vijay.abcnetbanking.User.Mangement.service.BeneficiaryService;
import com.vijay.abcnetbanking.User.Mangement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {

    @Autowired
    private BeneficiaryRepository beneficiaryRepository;

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<BeneficiaryDTO> getBeneficiaries(Long userId) {

        // if user is not found then throw exception
       User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        // add null pointer exception check for beneficiaries
        List<Beneficiary> beneficiaries = beneficiaryRepository.findByUser(user);
        if (beneficiaries.isEmpty()) {
            return List.of(); // return an empty list if no beneficiaries are found
        }
        return beneficiaries.stream().map(beneficiary -> {
            BeneficiaryDTO beneficiaryDTO = new BeneficiaryDTO();
            beneficiaryDTO.setId(beneficiary.getId());
            beneficiaryDTO.setName(beneficiary.getName());
            beneficiaryDTO.setAccountNumber(beneficiary.getAccountNumber());
            beneficiaryDTO.setAddress(beneficiary.getAddress());
            beneficiaryDTO.setEmail(beneficiary.getEmail());
            beneficiaryDTO.setMobile(beneficiary.getMobile());
           
            return beneficiaryDTO;
        }).collect(Collectors.toList());
    }

    @Override
    public BeneficiaryDTO addBeneficiary(Long userId, BeneficiaryDTO beneficiaryDTO) {
        if (beneficiaryRepository.existsByAccountNumberAndUserId(beneficiaryDTO.getAccountNumber(), userId)) {
            throw new BeneficiaryAlreadyExistsException("Beneficiary already exists for this user.");
        }

        // Validate  account number (this is a placeholder, actual validation logic may vary)
        if ( !isValidAccountNumber(beneficiaryDTO.getAccountNumber())) {
            throw new InvalidBeneficiaryException("Invalid account number " + beneficiaryDTO.getAccountNumber());
        }

        //get user by userId
        User user = getUserByUserId(userId);

        Beneficiary beneficiary = new Beneficiary();
        beneficiary.setAccountNumber(beneficiaryDTO.getAccountNumber());
        beneficiary.setName(beneficiaryDTO.getName());
        // set name,address,email,mobile
        beneficiary.setAddress(beneficiaryDTO.getAddress());
        beneficiary.setEmail(beneficiaryDTO.getEmail());
        beneficiary.setMobile(beneficiaryDTO.getMobile());

        // get user details from jwt token

        beneficiary.setUser(user);


        beneficiaryRepository.save(beneficiary);
        beneficiaryDTO.setId(beneficiary.getId());
        return beneficiaryDTO;
    }

    @Override
    public BeneficiaryDTO updateBeneficiary(Long userId, Long beneficiaryId, BeneficiaryDTO beneficiaryDTO) {
         //get user by userId
        User user = getUserByUserId(userId);


        Beneficiary beneficiary = beneficiaryRepository.findById(beneficiaryId).orElseThrow(() -> new RuntimeException("Beneficiary not found"));
        beneficiary.setName(beneficiaryDTO.getName());
        beneficiary.setAccountNumber(beneficiaryDTO.getAccountNumber());
        beneficiary.setAddress(beneficiaryDTO.getAddress());
        beneficiary.setEmail(beneficiaryDTO.getEmail());
        beneficiary.setMobile(beneficiaryDTO.getMobile());
        beneficiary.setUser(user);
    
        beneficiaryRepository.save(beneficiary);
        return beneficiaryDTO;
    }

    @Override
    public void deleteBeneficiary(Long userId, Long beneficiaryId) {

         //get user by userId
         getUserByUserId(userId);
         // if user is not found then throw exception

         if (!beneficiaryRepository.existsById(beneficiaryId)) {
            throw new RuntimeException("Beneficiary not found");
        }

        beneficiaryRepository.deleteById(beneficiaryId);
    }

    

    private boolean isValidAccountNumber(Long accountNumber) {

        // check if account number exists then return true otherwise return false
        return accountRepository.existsByAccountNumber(accountNumber);    
    }

    // write private method to get user by userId
    private User getUserByUserId(Long userId) {
        return userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
    }
}
