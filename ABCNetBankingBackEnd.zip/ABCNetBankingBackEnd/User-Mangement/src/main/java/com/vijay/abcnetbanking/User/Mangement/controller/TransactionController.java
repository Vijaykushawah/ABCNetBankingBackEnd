package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;
import com.vijay.abcnetbanking.User.Mangement.service.TransactionService;
import static com.vijay.abcnetbanking.User.Mangement.util.CommonUtil.isDateRangeInvalid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    @GetMapping("")
    public ResponseEntity<?> getTransactionHistory(
            @RequestParam Long accountId,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        try {
            Date start = DATE_FORMAT.parse(startDate);
            Date end = DATE_FORMAT.parse(endDate);

            // Validate date range
            if (isDateRangeInvalid(start, end)) {
                return ResponseEntity.status(400).body("Transactions older than 12 months are not available.");
            }

            List<TransactionDTO> transactions = transactionService.getTransactionHistory(accountId, start, end);
            return ResponseEntity.ok(transactions);
        } catch (ParseException e) {
            return ResponseEntity.status(400).body("Invalid date format.");
        }
    }

    @GetMapping("/download/pdf")
    public ResponseEntity<?> downloadPdfStatement(
            @RequestParam Long accountId,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        try {
            Date start = DATE_FORMAT.parse(startDate);
            Date end = DATE_FORMAT.parse(endDate);

            // Validate date range
            if (isDateRangeInvalid(start, end)) {
                return ResponseEntity.status(400).body("Transactions older than 12 months are not available.");
            }

            byte[] pdfContent = transactionService.generatePdfStatement(accountId, start, end);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=statement.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfContent);
        } catch (ParseException e) {
            return ResponseEntity.status(400).body("Invalid date format.");
        }
    }

    @GetMapping("/download/csv")
    public ResponseEntity<?> downloadCsvStatement(
            @RequestParam Long accountId,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        try {
            Date start = DATE_FORMAT.parse(startDate);
            Date end = DATE_FORMAT.parse(endDate);

            // Validate date range
            if (isDateRangeInvalid(start, end)) {
                return ResponseEntity.status(400).body("Transactions older than 12 months are not available.");
            }

            byte[] csvContent = transactionService.generateCsvStatement(accountId, start, end);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=statement.csv")
                    .contentType(MediaType.TEXT_PLAIN)
                    .body(csvContent);
        } catch (ParseException e) {
            return ResponseEntity.status(400).body("Invalid date format.");
        }
    }

   
}