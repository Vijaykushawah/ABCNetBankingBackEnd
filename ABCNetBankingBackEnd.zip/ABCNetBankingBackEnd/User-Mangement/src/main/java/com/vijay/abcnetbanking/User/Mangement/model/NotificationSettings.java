package com.vijay.abcnetbanking.User.Mangement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
import java.util.Date;



@Entity
@Data
public class NotificationSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "userId")
    private User user;//refer to User entity
    
    private Boolean emailAlerts;
    private Boolean smsAlerts;
    private Date createdDate;

    // Getters and Setters
}


