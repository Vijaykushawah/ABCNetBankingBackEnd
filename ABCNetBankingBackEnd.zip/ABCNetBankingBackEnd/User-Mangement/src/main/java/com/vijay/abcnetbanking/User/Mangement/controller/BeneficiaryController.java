package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.BeneficiaryDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.ErrorResponseDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.BeneficiaryAlreadyExistsException;
import com.vijay.abcnetbanking.User.Mangement.exception.InvalidBeneficiaryException;
import com.vijay.abcnetbanking.User.Mangement.service.BeneficiaryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/beneficiary")
public class BeneficiaryController {

    @Autowired
    private BeneficiaryService beneficiaryService;

    @GetMapping("/{userId}")
    public ResponseEntity<?> getBeneficiaries(@PathVariable Long userId) {
        try {
            List<BeneficiaryDTO> beneficiaries = beneficiaryService.getBeneficiaries(userId);
            return ResponseEntity.ok(beneficiaries);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
        }
    }

    @PostMapping("/{userId}")
    public ResponseEntity<?> addBeneficiary(@PathVariable Long userId, @RequestBody BeneficiaryDTO beneficiaryDTO) {
        try {
            BeneficiaryDTO addedBeneficiary = beneficiaryService.addBeneficiary(userId, beneficiaryDTO);
            return ResponseEntity.ok(addedBeneficiary);
        } catch (BeneficiaryAlreadyExistsException e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail",e.getMessage()));
        } catch (InvalidBeneficiaryException e) {
            return ResponseEntity.status(400).body(new ErrorResponseDTO("fail",e.getMessage()));
        }
    }

    @PutMapping("/{userId}/{beneficiaryId}")
public ResponseEntity<?> updateBeneficiary(@PathVariable Long userId, @PathVariable Long beneficiaryId, @RequestBody BeneficiaryDTO beneficiaryDTO) {
    try {
        BeneficiaryDTO updatedBeneficiary = beneficiaryService.updateBeneficiary(userId, beneficiaryId, beneficiaryDTO);
        return ResponseEntity.ok(updatedBeneficiary);
    } catch (InvalidBeneficiaryException e) {
        return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
    } catch (Exception e) {
        return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
    }
}

@DeleteMapping("/{userId}/{beneficiaryId}")
public ResponseEntity<?> deleteBeneficiary(@PathVariable Long userId, @PathVariable Long beneficiaryId) {
    try {
        beneficiaryService.deleteBeneficiary(userId, beneficiaryId);
        return ResponseEntity.noContent().build();
    } catch (Exception e) {
        return ResponseEntity.status(400).body(new ErrorResponseDTO("fail", e.getMessage()));
    }
}
}
