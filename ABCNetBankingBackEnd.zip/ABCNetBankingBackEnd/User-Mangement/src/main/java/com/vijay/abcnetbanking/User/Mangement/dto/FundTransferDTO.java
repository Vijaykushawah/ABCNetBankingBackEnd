package com.vijay.abcnetbanking.User.Mangement.dto;

import java.util.Date;
import lombok.Data;

@Data
public class FundTransferDTO {

    private Long id;
    private Double amount;
    private Date date;
    private String type;
    private String status;
    private Long fromAccountNumber;
    private Long toAccountNumber;
    private String errorMessage; // New field for error messages

    public FundTransferDTO() {
    }

    public FundTransferDTO(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    // Getters and Setters
}
