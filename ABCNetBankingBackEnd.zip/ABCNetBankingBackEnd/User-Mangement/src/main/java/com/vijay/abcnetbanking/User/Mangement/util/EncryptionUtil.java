package com.vijay.abcnetbanking.User.Mangement.util;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.io.*;
import java.security.SecureRandom;
import java.util.Base64;

public class EncryptionUtil {

    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final String ALGORITHM = "AES";
    private static final String KEY_FILE = "secret.key";
    private static final String IV_FILE = "iv.key";
    private static SecretKey secretKey;
    private static IvParameterSpec iv;

    static {
        try {
            File keyFile = new File(KEY_FILE);
            File ivFile = new File(IV_FILE);

            if (keyFile.exists() && ivFile.exists()) {
                // Load the secret key and IV from the files
                secretKey = loadSecretKey(KEY_FILE);
                iv = loadIv(IV_FILE);
            } else {
                // Generate a new secret key and IV
                KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM);
                keyGen.init(256); // for example, 256-bit AES
                secretKey = keyGen.generateKey();

                byte[] ivBytes = new byte[16]; // AES block size is 16 bytes
                SecureRandom random = new SecureRandom();
                random.nextBytes(ivBytes);
                iv = new IvParameterSpec(ivBytes);

                // Save the secret key and IV to the files
                saveSecretKey(secretKey, KEY_FILE);
                saveIv(iv, IV_FILE);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error initializing EncryptionUtil", e);
        }
    }

    public static String encrypt(String input) {
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
            byte[] encryptedBytes = cipher.doFinal(input.getBytes());
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            throw new RuntimeException("Error encrypting the input", e);
        }
    }

    public static String decrypt(String input) {
        try {
            byte[] encryptedBytes = Base64.getDecoder().decode(input);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            return new String(decryptedBytes);
        } catch (Exception e) {
            throw new RuntimeException("Error decrypting the input", e);
        }
    }

    private static void saveSecretKey(SecretKey secretKey, String fileName) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(secretKey.getEncoded());
        }
    }

    private static SecretKey loadSecretKey(String fileName) throws IOException {
        byte[] keyBytes = new byte[32]; // 256-bit key
        try (FileInputStream fis = new FileInputStream(fileName)) {
            fis.read(keyBytes);
        }
        return new javax.crypto.spec.SecretKeySpec(keyBytes, ALGORITHM);
    }

    private static void saveIv(IvParameterSpec iv, String fileName) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(iv.getIV());
        }
    }

    private static IvParameterSpec loadIv(String fileName) throws IOException {
        byte[] ivBytes = new byte[16]; // AES block size is 16 bytes
        try (FileInputStream fis = new FileInputStream(fileName)) {
            fis.read(ivBytes);
        }
        return new IvParameterSpec(ivBytes);
    }
}