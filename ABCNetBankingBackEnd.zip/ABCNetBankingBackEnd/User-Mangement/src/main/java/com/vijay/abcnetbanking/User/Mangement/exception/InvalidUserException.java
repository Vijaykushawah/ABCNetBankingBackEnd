package com.vijay.abcnetbanking.User.Mangement.exception;

public class InvalidUserException extends RuntimeException {
    public InvalidUserException(String message) {
        super(message);
    }                   
}
