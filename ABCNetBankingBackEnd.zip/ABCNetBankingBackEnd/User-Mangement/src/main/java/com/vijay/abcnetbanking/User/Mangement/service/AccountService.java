package com.vijay.abcnetbanking.User.Mangement.service;

import java.util.List;

import com.vijay.abcnetbanking.User.Mangement.dto.AccountOpeningDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.DepositDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.TransactionDTO;

public interface AccountService {
    AccountOpeningDTO getAccountDetails(Long userId);
    AccountOpeningDTO openAccount(AccountOpeningDTO accountOpeningDTO);
    List<AccountOpeningDTO> getAccountDetailsByEmail(String email);
    void depositMoney(DepositDTO depositDTO);
    List<TransactionDTO> getTransactionsByAccountNumber(Long accountNumber);
}
