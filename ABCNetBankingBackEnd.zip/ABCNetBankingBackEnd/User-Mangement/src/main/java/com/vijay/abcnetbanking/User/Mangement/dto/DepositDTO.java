package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class DepositDTO {
    private Long accountNumber;
    private Double amount;

    // Getters and Setters
}
