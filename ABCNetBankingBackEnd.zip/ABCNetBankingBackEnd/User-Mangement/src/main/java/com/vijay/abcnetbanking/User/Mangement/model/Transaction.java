package com.vijay.abcnetbanking.User.Mangement.model;




import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double amount;
    private Date date;
    private String description;
    private String type;
    private String status;
    private Date createdDate;


    @ManyToOne
    @JoinColumn(name = "account_id")
    private Account account;

    // Getters and Setters
}
