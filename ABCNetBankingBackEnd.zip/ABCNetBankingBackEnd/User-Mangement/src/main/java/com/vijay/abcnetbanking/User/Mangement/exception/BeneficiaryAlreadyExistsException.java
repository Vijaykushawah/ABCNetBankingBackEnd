package com.vijay.abcnetbanking.User.Mangement.exception;



public class BeneficiaryAlreadyExistsException extends RuntimeException {

    public BeneficiaryAlreadyExistsException(String message) {
        super(message);
    }
}
