package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class ChatRequestDTO {

    private String query;

    // Getters and Setters
}
