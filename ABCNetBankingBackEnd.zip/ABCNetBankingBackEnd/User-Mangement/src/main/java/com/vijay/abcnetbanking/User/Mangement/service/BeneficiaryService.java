package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.BeneficiaryDTO;

import java.util.List;

public interface BeneficiaryService {
    List<BeneficiaryDTO> getBeneficiaries(Long userId);
    BeneficiaryDTO addBeneficiary(Long userId,BeneficiaryDTO beneficiaryDTO);
    BeneficiaryDTO updateBeneficiary(Long userId, Long beneficiaryId, BeneficiaryDTO beneficiaryDTO);
    void deleteBeneficiary(Long userId, Long beneficiaryId);
}
