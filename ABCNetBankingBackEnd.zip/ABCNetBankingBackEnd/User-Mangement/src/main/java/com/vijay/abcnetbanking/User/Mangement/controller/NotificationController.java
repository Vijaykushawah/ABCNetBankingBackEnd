package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.dto.NotificationDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.NotificationSettingsDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Notification;
import com.vijay.abcnetbanking.User.Mangement.service.NotificationService;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

     @PostMapping("/send")
    public ResponseEntity<Void> sendNotification(@Valid @RequestBody NotificationDTO notificationDTO) {
        notificationService.sendNotification(notificationDTO);
        return ResponseEntity.noContent().build();
    }

     @PostMapping("/settings/{userId}")
    public ResponseEntity<?> saveNotificationSettings(@PathVariable Long userId, @Valid @RequestBody NotificationSettingsDTO settingsDTO) {
        NotificationSettingsDTO notificationSettingsDTO = notificationService.saveNotificationSettings(userId, settingsDTO);
        return ResponseEntity.ok(notificationSettingsDTO);
    }

    @GetMapping("/settings/{userId}")
    public ResponseEntity<NotificationSettingsDTO> getNotificationSettings(@PathVariable Long userId) {
        NotificationSettingsDTO settingsDTO = notificationService.getNotificationSettings(userId);
        return ResponseEntity.ok(settingsDTO);
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<Notification>> getNotificationHistory(@PathVariable Long userId) {
        List<Notification> notifications = notificationService.getNotificationHistory(userId);
        return ResponseEntity.ok(notifications);
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return ResponseEntity.badRequest().body(errors);
    }
}
