package com.vijay.abcnetbanking.User.Mangement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class Beneficiary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long accountNumber;
    // add name, email, address and mobile fields
    private String name;
    private String email;
    private String address;
    private String mobile;
    

    @ManyToOne

    @JoinColumn(name = "user_id")
    private User user;

    // Getters and Setters
}
