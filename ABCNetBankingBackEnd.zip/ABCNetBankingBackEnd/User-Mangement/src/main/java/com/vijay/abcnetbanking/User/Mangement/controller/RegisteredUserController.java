package com.vijay.abcnetbanking.User.Mangement.controller;

import com.vijay.abcnetbanking.User.Mangement.model.User;
import com.vijay.abcnetbanking.User.Mangement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class RegisteredUserController {

    @Autowired
    private UserService userService;

    @GetMapping("/search")
    public ResponseEntity<?> searchUser(@RequestParam(required = true) String emailOrMobile) {
        if (emailOrMobile == null ) {
            return ResponseEntity.badRequest().build();
        }

        User user = userService.findByMobileOrEmail(emailOrMobile);
        if (user == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(user);
    }
} 
