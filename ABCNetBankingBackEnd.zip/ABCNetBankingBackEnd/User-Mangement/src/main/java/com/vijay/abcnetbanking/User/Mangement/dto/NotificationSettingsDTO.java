package com.vijay.abcnetbanking.User.Mangement.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationSettingsDTO {


   

    @NotNull
    private Boolean emailAlerts;

    @NotNull
    private Boolean smsAlerts;

    // Getters and Setters
}


