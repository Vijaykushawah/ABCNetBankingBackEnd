package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;

@Data
public class ChatResponseDTO {

    private String response;

    // Getters and Setters
}
