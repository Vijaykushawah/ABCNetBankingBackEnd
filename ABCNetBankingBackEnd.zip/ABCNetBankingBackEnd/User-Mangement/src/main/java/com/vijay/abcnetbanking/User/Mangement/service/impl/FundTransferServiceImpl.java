package com.vijay.abcnetbanking.User.Mangement.service.impl;

import com.vijay.abcnetbanking.User.Mangement.dto.FundTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.dto.IntraBankTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.exception.InsufficientBalanceException;
import com.vijay.abcnetbanking.User.Mangement.exception.InvalidBeneficiaryException;
import com.vijay.abcnetbanking.User.Mangement.dto.InterBankTransferDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Account;
import com.vijay.abcnetbanking.User.Mangement.model.Beneficiary;
import com.vijay.abcnetbanking.User.Mangement.model.FundTransfer;
import com.vijay.abcnetbanking.User.Mangement.model.Transaction;
import com.vijay.abcnetbanking.User.Mangement.repository.AccountRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.BeneficiaryRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.FundTransferRepository;
import com.vijay.abcnetbanking.User.Mangement.repository.TransactionRepository;
import com.vijay.abcnetbanking.User.Mangement.service.FundTransferService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class FundTransferServiceImpl implements FundTransferService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private BeneficiaryRepository beneficiaryRepository;

    @Autowired
    private FundTransferRepository fundTransferRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public FundTransferDTO intraBankTransfer(IntraBankTransferDTO intraBankTransferDTO) {
        Account fromAccount = accountRepository.findByAccountNumber(intraBankTransferDTO.getFromAccountNumber())
                .orElseThrow(() -> new RuntimeException("From account not found"));
        Account toAccount = accountRepository.findByAccountNumber(intraBankTransferDTO.getToAccountNumber())
                .orElseThrow(() -> new RuntimeException("To account not found"));
          
        Beneficiary beneficiary = beneficiaryRepository.findByAccountNumber(
            intraBankTransferDTO.getToAccountNumber())
                    .orElseThrow(() -> new InvalidBeneficiaryException("Invalid or inactive beneficiary."));
    
        // check if beneficiary is added by user
          if (beneficiary.getUser().getId() != fromAccount.getUser().getId()) {
            throw new InvalidBeneficiaryException("beneficiary is not added.");
        }

        if (fromAccount.getBalance() < intraBankTransferDTO.getAmount()) {
            throw new RuntimeException("Insufficient balance");
        }

        fromAccount.setBalance(fromAccount.getBalance() - intraBankTransferDTO.getAmount());
        toAccount.setBalance(toAccount.getBalance() + intraBankTransferDTO.getAmount());

        accountRepository.save(fromAccount);
        accountRepository.save(toAccount);

        FundTransfer fundTransfer = new FundTransfer();
        fundTransfer.setAmount(intraBankTransferDTO.getAmount());
        fundTransfer.setDate(new Date());
        fundTransfer.setType("INTRA_BANK");
        fundTransfer.setStatus("SUCCESS");
        fundTransfer.setFromAccount(fromAccount);
        fundTransfer.setToAccount(toAccount);

        fundTransferRepository.save(fundTransfer);

        FundTransferDTO fundTransferDTO = new FundTransferDTO();
        fundTransferDTO.setId(fundTransfer.getId());
        fundTransferDTO.setAmount(fundTransfer.getAmount());
        fundTransferDTO.setDate(fundTransfer.getDate());
        fundTransferDTO.setType(fundTransfer.getType());
        fundTransferDTO.setStatus(fundTransfer.getStatus());
        fundTransferDTO.setFromAccountNumber(fromAccount.getAccountNumber());
        fundTransferDTO.setToAccountNumber(toAccount.getAccountNumber());
        saveTransaction(fundTransfer, fromAccount, toAccount);
        return fundTransferDTO;
    }

    @Override
    public FundTransferDTO interBankTransfer(InterBankTransferDTO interBankTransferDTO) {
        Account fromAccount = accountRepository.findByAccountNumber(interBankTransferDTO.getFromAccountNumber())
                .orElseThrow(() -> new RuntimeException("From account not found"));

        // fromAccount and toAccount can not be   same 
        if (interBankTransferDTO.getFromAccountNumber().equals(interBankTransferDTO.getToAccountNumber())) {
            throw new RuntimeException("From and to account can not be same.");
        }
                

        Beneficiary beneficiary = beneficiaryRepository.findByAccountNumber(
                interBankTransferDTO.getToAccountNumber())
                .orElseThrow(() -> new InvalidBeneficiaryException("Invalid or inactive beneficiary."));

                // check if beneficiary is added by user
        if (beneficiary.getUser().getId() != fromAccount.getUser().getId()) {
            throw new InvalidBeneficiaryException("Beneficiary is not added");
        }

        if (fromAccount.getBalance() < interBankTransferDTO.getAmount()) {
            throw new InsufficientBalanceException("Insufficient balance for this transaction.");
        }

        fromAccount.setBalance(fromAccount.getBalance() - interBankTransferDTO.getAmount());
        accountRepository.save(fromAccount);

        FundTransfer fundTransfer = new FundTransfer();
        fundTransfer.setAmount(interBankTransferDTO.getAmount());
        fundTransfer.setDate(new Date());
        fundTransfer.setType("INTER_BANK");
        fundTransfer.setStatus("PENDING");
        fundTransfer.setFromAccount(fromAccount);
        fundTransfer.setToAccount(null); // Inter-bank transfer, toAccount is not in our system

        fundTransferRepository.save(fundTransfer);

        // Simulate inter-bank transfer processing
        // In a real application, you would integrate with a payment gateway here
        fundTransfer.setStatus("SUCCESS");
        fundTransferRepository.save(fundTransfer);

        FundTransferDTO fundTransferDTO = new FundTransferDTO();
        fundTransferDTO.setId(fundTransfer.getId());
        fundTransferDTO.setAmount(fundTransfer.getAmount());
        fundTransferDTO.setDate(fundTransfer.getDate());
        fundTransferDTO.setType(fundTransfer.getType());
        fundTransferDTO.setStatus(fundTransfer.getStatus());
        fundTransferDTO.setFromAccountNumber(fromAccount.getAccountNumber());
        fundTransferDTO.setToAccountNumber(interBankTransferDTO.getToAccountNumber());
        saveTransaction(fundTransfer, fromAccount, null);

        return fundTransferDTO;
    }

    // write method to save transaction using transactionRepository
   private void saveTransaction(FundTransfer fundTransfer, Account fromAccount, Account toAccount) {
        // write code to save transaction
        Transaction transaction = new Transaction();
        transaction.setAmount(fundTransfer.getAmount());
        transaction.setDate(new Date());
        transaction.setDescription("Fund transfer");
        transaction.setAccount(fromAccount);
        transaction.setType("DEBIT");
        transaction.setStatus("SUCCESS");
        transactionRepository.save(transaction);

        if (toAccount != null) {
            Transaction creditTransaction = new Transaction();
            creditTransaction.setAmount(fundTransfer.getAmount());
            creditTransaction.setDate(new Date());
            creditTransaction.setDescription("Fund transfer");
            creditTransaction.setAccount(toAccount);
            creditTransaction.setType("CREDIT");
            creditTransaction.setStatus("SUCCESS");
            transactionRepository.save(creditTransaction);
        }

    }

}
