package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.UserDTO;
import com.vijay.abcnetbanking.User.Mangement.model.User;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface UserService {
    User createUser(User user);
    String generate2FACode(User user);
    boolean verify2FACode(User user, String code);
    User save(User user);
    User update(User user);
    User findById(Long id);
    User findByEmail(String email);
    User findByMobile(String mobile);
    User findByMobileOrEmail(String mobileOrEmail);
    String generateOtp(User user);
    boolean verifyOtp(User user, String otp);
    UserDTO loginUser(User loginRequest);
    void logout(HttpServletRequest request, HttpServletResponse response);

}