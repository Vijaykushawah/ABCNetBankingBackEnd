package com.vijay.abcnetbanking.User.Mangement.service;

import com.vijay.abcnetbanking.User.Mangement.dto.BankDTO;
import com.vijay.abcnetbanking.User.Mangement.model.Bank;


import java.util.List;

public interface BankService {
    Bank createBank(BankDTO bankDTO);
    Bank updateBank(Long id, BankDTO bankDTO);
    void deleteBank(Long id);
    Bank getBankById(Long id);
    List<Bank> getAllBanks();
}
