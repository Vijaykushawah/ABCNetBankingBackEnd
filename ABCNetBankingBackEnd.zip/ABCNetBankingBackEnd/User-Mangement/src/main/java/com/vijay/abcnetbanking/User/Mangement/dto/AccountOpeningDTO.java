package com.vijay.abcnetbanking.User.Mangement.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;


@Data
public class AccountOpeningDTO {

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotNull(message = "Account number is required")
    private Long accountNumber;

    @NotNull(message = "Bank ID is required")
    private Long bankId;

    @NotNull(message = "High school certificate is required")
    private MultipartFile highSchoolCertificate;

    @NotNull(message = "Signature is required")
    private MultipartFile signature;

    @NotNull(message = "Photo is required")
    private MultipartFile photo;

    // add User and Bank DTOs to the response
    private UserDTO user;
    private BankDTO bank;
    private List<TransactionDTO> transactions;
    private Double balance;
    private Double availableCredit;


    // Getters and Setters
}
