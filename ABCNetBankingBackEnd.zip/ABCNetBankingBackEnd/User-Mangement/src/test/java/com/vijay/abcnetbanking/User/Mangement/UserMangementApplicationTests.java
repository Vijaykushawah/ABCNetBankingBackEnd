package com.vijay.abcnetbanking.User.Mangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
